<?php
/**
 * Do not put language files here, they are handled by WordPress.org.
 */